package com.api.school.util;

public enum Role {
    ADMIN,
    USER
}
